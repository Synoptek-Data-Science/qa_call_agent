import os
import re
import json
import logging
import pandas as pd
from io import BytesIO
from scipy.io import wavfile
from pydub import AudioSegment
from azure.storage.blob import BlobServiceClient, BlobClient, ContentSettings
from openai import AzureOpenAI
from langchain_community.chat_models import AzureChatOpenAI
from langchain_core.prompts import PromptTemplate
import tempfile
import pyodbc 
import zipfile

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

sharepoint_link = "https://synoptek.sharepoint.com/:f:/s/AIMS-QAonAgentCalls/ErfLX9wJjN1DrBU72SGg-18B3KYXqK1lPtbMzQ5F5A5auw?e=VSo7df" 

# Constants
AUDIO_FILE_EXTENSION = '.wav'
local_folder = "./input_audio_files"
output_folder = "./qa_call_analysis_output_files"

# Azure Blob Storage configuration
azure_blob_connection_string = "DefaultEndpointsProtocol=https;AccountName=stgaccountaims;AccountKey=lnu8tomgJHy9uSPh46bfEX3vDhAc6eys8Vklu7viyBWv7/WYOajOQwQ4W+eFBBaySlQ9Sdbm+Pib+AStkY81/g==;EndpointSuffix=core.windows.net"
azure_blob_container_name = "container-qa-analysis"

# Azure OpenAI configuration
azure_openai_api_key ="b121bf4513614689b797d27c3b24eec8"
azure_endpoint = "https://dev-aims-ai-qa.openai.azure.com/"

# MSSQL database configuration
mssql_server = 'qa-call-analysis-db.database.windows.net'  
mssql_database = 'qa-call-analysis-db'  
mssql_username = 'qa-call-analysis'  
mssql_password = '$ynoptek@321'  
mssql_table = 'scorecard_v1'  

# Function to set up Azure OpenAI models
def azure_openai_setup(azure_openai_api_key, azure_endpoint):
    try:
        logger.info("Setting up Azure OpenAI")
        deployment_gpt4o_azure = 'qa-call-agent-gpt4o'
        llm_azure_resp = AzureChatOpenAI(
            model_name=deployment_gpt4o_azure,
            openai_api_key=azure_openai_api_key,
            azure_endpoint=azure_endpoint,
            openai_api_version="2024-04-01-preview",
            temperature=0,
            max_tokens=4000,
            model_kwargs={'seed': 123}
        )
        logger.info("Azure OpenAI setup completed")
        return llm_azure_resp
    except Exception as e:
        logger.exception("Error setting up Azure OpenAI: %s", e)
        raise e

# Set up Azure OpenAI models
llm_azure_resp = azure_openai_setup(azure_openai_api_key, azure_endpoint)

# Initialize the Azure OpenAI client
client = AzureOpenAI(
    api_key=azure_openai_api_key,
    api_version="2024-02-01",
    azure_endpoint=azure_endpoint
)

# Function to upload files to Azure Blob Storage within a folder
def upload_to_azure_blob_storage(connection_string, container_name, file_path, relative_path):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        blob_path = os.path.join(relative_path, os.path.basename(file_path))
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)
        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
        logger.info(f"Uploaded {file_path} to Azure Blob Storage in folder {blob_path}.")
    except Exception as e:
        logger.exception("Error uploading file to Azure Blob Storage: %s", e)
        raise e

def download_files():
    blob_service_client = BlobServiceClient.from_connection_string(azure_blob_connection_string)
    container_client = blob_service_client.get_container_client(azure_blob_container_name)
    if not os.path.exists(local_folder):
        os.makedirs(local_folder)
    blobs = container_client.list_blobs()
    downloaded_blob_paths = []
    for blob in blobs:
        download_file_path = os.path.join(local_folder, blob.name)
        os.makedirs(os.path.dirname(download_file_path), exist_ok=True)
        with open(download_file_path, "wb") as download_file:
            download_file.write(container_client.download_blob(blob.name).readall())
        logger.info(f"Downloaded {blob.name} to {download_file_path}")
        downloaded_blob_paths.append(download_file_path)
    return downloaded_blob_paths

# Function to transcribe audio
def transcribe_audio(file_path):
    with open(file_path, "rb") as audio_file:
        result = client.audio.transcriptions.create(
            file=audio_file,
            model="qa-call-agent-dev-01"
        )
    transcript = result.text
    relative_path = os.path.relpath(file_path, local_folder)
    transcription_file = os.path.join(output_folder, relative_path).replace(".wav", ".txt")
    # os.makedirs(os.path.dirname(transcription_file), exist_ok=True)
    # with open(transcription_file, 'w', encoding='utf-8') as f:
    #     f.write(transcript)
    return transcript

# Function to evaluate a call and generate a score
def evaluate_call(llm_azure_resp, transcript, template):
    prompt = PromptTemplate(template=template, input_variables=["transcript"])
    response = llm_azure_resp.invoke(prompt.format(transcript=transcript))
    evaluation = response.content.strip()
    return evaluation

# Function to extract scorecard from evaluation
def extract_scorecard_from_evaluation(evaluation_text):
    criteria_pattern = re.compile(r'"Criteria":\s*"([^"]+)"')
    scale_pattern = re.compile(r'"Scale":\s*"([^"]+)"')
    score_pattern = re.compile(r'"Score":\s*(?:"([^"]+)"|(\d+))')
    notes_pattern = re.compile(r'"Notes":\s*"([^"]+)"')
    criteria = criteria_pattern.findall(evaluation_text)
    scales = scale_pattern.findall(evaluation_text)
    scores = [s1 if s1 else s2 for s1, s2 in score_pattern.findall(evaluation_text)]
    notes = notes_pattern.findall(evaluation_text)
    notes = [note.replace('\n', ' ').strip() for note in notes]
    if len(criteria) == len(scales) == len(scores) == len(notes):
        return pd.DataFrame({
            "Criteria": criteria,
            "Scale": scales,
            "Score": scores,
            "Notes": notes
        })
    else:
        raise ValueError("Mismatch in lengths of extracted fields. Check the regex patterns and evaluation text format.")

def extract_agent_email_id(file_name):
                print(f"Extracting email from file name: {file_name}")
                email_pattern = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')
                match = email_pattern.search(file_name)
                if match:
                    email = match.group(0)
                    print(f"Extracted email: {email}")
                    return email
                else:
                    print("No email found")
                    return "NA"
                
# Function to format the extracted scorecard data into the expected output format
def format_scorecard_to_expected(df, file_name, transcript_location, score_location):
    # Define the expected columns
    expected_columns = [
        'filename', 'transcript location', 'score location', 'agent email id',
        'proper greeting 0-1', 'proper greeting notes',
        'confirmation of contact and company 0-2', 'confirmation of contact and company notes',
        'demonstrated active listening 0-5', 'demonstrated active listening notes',
        'problem resolution 0-10', 'problem resolution notes',
        'remote support 0-1', 'remote support notes',
        'professionalism and courtesy 0-2', 'professionalism and courtesy notes',
        'closing 0-5', 'closing notes',
        'case number provision 0-1', 'case number provision notes'
    ]

    # Initialize a dictionary to hold the row data
    row_data = {
        'id': '',  # Fill with appropriate id if available
        'filename': file_name,
        'transcript location': transcript_location,
        'score location': score_location,
        'agent email id': extract_agent_email_id(file_name)
    }

    print('transcript_location',transcript_location)
    print('scorefile_location',score_location)
    # Map the DataFrame rows to the expected format
    for index, row in df.iterrows():
        if 'Proper Greeting' in row['Criteria']:
            row_data['proper greeting 0-1'] = row['Score']
            row_data['proper greeting notes'] = row['Notes']
        elif 'Confirmation of Contact and Company' in row['Criteria']:
            row_data['confirmation of contact and company 0-2'] = row['Score']
            row_data['confirmation of contact and company notes'] = row['Notes']
        elif 'Demonstrated Active Listening' in row['Criteria']:
            row_data['demonstrated active listening 0-5'] = row['Score']
            row_data['demonstrated active listening notes'] = row['Notes']
        elif 'Problem Resolution' in row['Criteria']:
            row_data['problem resolution 0-10'] = row['Score']
            row_data['problem resolution notes'] = row['Notes']
        elif 'Remote Support' in row['Criteria']:
            row_data['remote support 0-1'] = row['Score']
            row_data['remote support notes'] = row['Notes']
        elif 'Professionalism and Courtesy' in row['Criteria']:
            row_data['professionalism and courtesy 0-2'] = row['Score']
            row_data['professionalism and courtesy notes'] = row['Notes']
        elif 'Closing' in row['Criteria']:
            row_data['closing 0-5'] = row['Score']
            row_data['closing notes'] = row['Notes']
        elif 'Case Number Provision' in row['Criteria']:
            row_data['case number provision 0-1'] = row['Score']
            row_data['case number provision notes'] = row['Notes']

    # Convert the row data dictionary to a DataFrame
    formatted_df = pd.DataFrame([row_data], columns=expected_columns)

    return formatted_df

def upload_csv_to_mssql(transformed_df, server, database, username, password, table):
    conn = pyodbc.connect(
        f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password};Connection Timeout=30')
    cursor = conn.cursor()

    # Create table with predefined schema if it does not exist
    cursor.execute(f"""
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '{table}')
    CREATE TABLE {table} (
    id INT PRIMARY KEY IDENTITY(1,1),
    filename_ VARCHAR(255),
    transcript_location VARCHAR(MAX),
    scorefile_location VARCHAR(MAX),
    agent_email_id VARCHAR(MAX),
    proper_greeting_0_1 INT,
    proper_greeting_notes VARCHAR(MAX),
    confirmation_of_contact_and_company_0_2 INT,
    confirmation_of_contact_and_company_notes VARCHAR(MAX),
    demonstrated_active_listening_0_5 INT,
    demonstrated_active_listening_notes VARCHAR(MAX),
    problem_resolution_0_10 INT,
    problem_resolution_notes VARCHAR(MAX),
    remote_support_0_1 INT,
    remote_support_notes VARCHAR(MAX),
    professionalism_and_courtesy_0_2 INT,
    professionalism_and_courtesy_notes VARCHAR(MAX),
    closing_0_5 INT,
    closing_notes VARCHAR(MAX),
    case_number_provision_0_1 INT,
    case_number_provision_notes VARCHAR(MAX),
    created_at DATETIME2 DEFAULT SYSDATETIME()
);
    """)
    conn.commit()

    for index, row in transformed_df.iterrows():
        params = [
            row['filename_'],
            row['transcript_location'],
            row['scorefile_location'],
            row['agent_email_id'],
            row['proper_greeting_0_1'],
            row['proper_greeting_notes'],
            row['confirmation_of_contact_and_company_0_2'],
            row['confirmation_of_contact_and_company_notes'],
            row['demonstrated_active_listening_0_5'],
            row['demonstrated_active_listening_notes'],
            row['problem_resolution_0_10'],
            row['problem_resolution_notes'],
            row['remote_support_0_1'],
            row['remote_support_notes'],
            row['professionalism_and_courtesy_0_2'],
            row['professionalism_and_courtesy_notes'],
            row['closing_0_5'],
            row['closing_notes'],
            row['case_number_provision_0_1'],
            row['case_number_provision_notes'],
        ]

        # Check if row already exists
        cursor.execute(f"SELECT 1 FROM {table} WHERE filename_ = ?", row['filename_'])
        if cursor.fetchone():
            # Update existing row
            cursor.execute(f"""
            UPDATE {table}
            SET 
                transcript_location = ?, 
                scorefile_location = ?, 
                agent_email_id = ?,
                proper_greeting_0_1 = ?, 
                proper_greeting_notes = ?, 
                confirmation_of_contact_and_company_0_2 = ?, 
                confirmation_of_contact_and_company_notes = ?, 
                demonstrated_active_listening_0_5 = ?, 
                demonstrated_active_listening_notes = ?, 
                problem_resolution_0_10 = ?, 
                problem_resolution_notes = ?,
                remote_support_0_1 = ?, 
                remote_support_notes = ?, 
                professionalism_and_courtesy_0_2 = ?, 
                professionalism_and_courtesy_notes = ?, 
                closing_0_5 = ?, 
                closing_notes = ?, 
                case_number_provision_0_1 = ?, 
                case_number_provision_notes = ?
            WHERE filename_ = ?
            """, params + [row['filename_']])
        else:
            # Insert new row
            cursor.execute(f"""
            INSERT INTO {table} (
                filename_,
                transcript_location,
                scorefile_location,
                agent_email_id,
                proper_greeting_0_1, 
                proper_greeting_notes, 
                confirmation_of_contact_and_company_0_2, 
                confirmation_of_contact_and_company_notes, 
                demonstrated_active_listening_0_5, 
                demonstrated_active_listening_notes, 
                problem_resolution_0_10, 
                problem_resolution_notes, 
                remote_support_0_1, 
                remote_support_notes, 
                professionalism_and_courtesy_0_2, 
                professionalism_and_courtesy_notes, 
                closing_0_5, 
                closing_notes, 
                case_number_provision_0_1,
                case_number_provision_notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, params)
        conn.commit()
        logger.info(f"Uploaded transformed DataFrame to MSSQL table {table}.")
        
def zip_output_files(base_folder, zip_file_path):
    subfolders = [f for f in os.listdir(base_folder) if os.path.isdir(os.path.join(base_folder, f))]
    if subfolders:
        subfolder = os.path.join(base_folder, subfolders[0])
        with zipfile.ZipFile(zip_file_path, 'w') as zipf:
            for root, dirs, files in os.walk(subfolder):
                for file in files:
                    if file.endswith('.txt') or file.endswith('.csv'):  # Only include .txt and .csv files
                        file_path = os.path.join(root, file)
                        # Remove the subfolder name from the archive path
                        arcname = os.path.relpath(file_path, subfolder)
                        zipf.write(file_path, arcname)
        logger.info(f"Zipped output files to {zip_file_path}")
    else:
        logger.info(f"No subfolders found in {base_folder}")
    
# Function to delete audio files from Azure Blob Storage
def delete_blob_files(connection_string, container_name, folder_path):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service_client.get_container_client(container_name)
        blobs = container_client.list_blobs(name_starts_with=folder_path)
        for blob in blobs:
            blob_client = container_client.get_blob_client(blob.name)
            blob_client.delete_blob()
            logger.info(f"Deleted {blob.name} from Azure Blob Storage.")
    except Exception as e:
        logger.exception("Error deleting file from Azure Blob Storage: %s", e)
        raise e

# Evaluation template
template = """
Given a transcript of a customer support call, evaluate the performance of the support representative based on the following criteria. Each criterion should be rated on a scale provided with each question. from 0 to 5, where 0 indicates the criterion was not met at all, and 5 indicates the criterion was fully met. Additionally, provide specific comments or notes for each criterion to justify the given score.

1) Proper Greeting (rate on a scale from 0 to 1, where 0 indicates the criterion was not met at all, and 1 indicates the criterion was met): Did the representative start the call with a professional and courteous greeting? For example, "Thank you for calling [Synoptek or Service Desk], My name is [name], how can I help you?

2) Confirmation of Contact and Company (rate on a scale from 0 to 2, where 0 indicates the criterion was not met at all, and 2 indicates the criterion was fully met): Did the representative explicitly ask about the caller's name/identity? Did the representative explicitly ask for the company name the caller is representing or calling from? The representative MUST ask for the company name and receive it from the caller in order to get credit.

3) Demonstrated Active Listening (rate on a scale from 0 to 5, where 0 indicates the criterion was not met at all, and 5 indicates the criterion was fully met): Did the representative demonstrate active listening by restating or summarizing the caller's issues or concerns to ensure understanding? Did the representative ask relevant follow-up and troubleshooting questions that build on what the customer has already said?

4) Problem Resolution (rate on a scale from 0 to 10, where 0 indicates the criterion was not met at all, and 10 indicates the criterion was fully met): Was the representative able to address and resolve the caller's issue during the call, or provide a clear path toward resolution? Did the representative perform relevant troubleshooting steps?

5) Remote Support (if remote connection was not needed, put "N/A" for the score; if remote connection was needed, rate on a scale from 0 to 1, where 0 indicates permission was not obtained, and 1 indicates permission was obtained): Did the representative need to remotely connect to the caller's system in order to provide assistance? If so, did the representative verbally obtain explicit permission from the caller before connecting to their system? For example, did the representative ask "Do I have your permission to connect to your system remotely?" or something similar? To be clear, implied permission is NOT ENOUGH to get a score of 1. The representative MUST explicitly ask for permission and receive verbal affirmation from the caller!

6) Professionalism and Courtesy (rate on a scale from 0 to 2, where 0 indicates the criterion was not met at all, and 2 indicates the criterion was fully met): Did the representative maintain a professional and courteous demeanor throughout the call? Did the agent explain any holds/dead air in advance or avoided holds/dead air entirely?

7) Closing (rate on a scale from 0 to 5, where 0 indicates the criterion was not met at all, and 5 indicates the criterion was fully met): Did the representative end the call on a positive note, confirming that the caller's concerns were addressed and asking if there was anything else they could help with? Did the representative explicitly ask permission to close the case? (this last question is worth 2 points in the score)

8) Did the representative verbally provide the caller with an explicit case number (rate on a scale from 0 to 1, where 0 indicates the criterion was not met at all, and 1 indicates the criterion was met)? If a verbal case number was provided, comment in the Notes as to when in the call the case number was provided by a percentage of the call duration. It should occur within the first 2 minutes of the call.

For each criterion, provide a score based on the transcript, followed by notes that include direct quotes or observations from the call to support your rating. Your output should summarize the representative's performance in a structured and detailed manner, similar to a scorecard, and provide a table in json format that contains the questions and answers. The table should have 4 columns: Criteria, Scale, Score, and Notes.
"""

if __name__ == "__main__":
    downloaded_blob_paths = download_files()
    all_files = [os.path.join(root, file) for root, _, files in os.walk(local_folder) for file in files]

    evaluation_results = []

    for file in all_files:
        if file.endswith(".wav"):
            transcript = transcribe_audio(file)
            evaluation = evaluate_call(llm_azure_resp, transcript, template)
            scores_and_notes_df = extract_scorecard_from_evaluation(evaluation)
            evaluation_results.append(scores_and_notes_df)

            # Save evaluation results to a CSV file in the output folder
            relative_path = os.path.relpath(file, start=local_folder)
            directory_path = os.path.dirname(relative_path)
            output_relative_path = os.path.join(output_folder, directory_path)
            csv_file_name = os.path.join(output_relative_path, f"{os.path.basename(relative_path)}.csv")
            csv_file_name_sh = csv_file_name.replace(".wav", ".csv")
            csv_file_name_sh = sharepoint_link + csv_file_name_sh.replace('.', '')
            os.makedirs(output_relative_path, exist_ok=True)
            scores_and_notes_df.to_csv(csv_file_name, index=False)

            # Save the transcript to the output folder
            transcription_output_file = os.path.join(output_relative_path, f"{os.path.basename(relative_path)}.txt")
            transcription_output_file_sh = transcription_output_file.replace(".wav", ".txt")
            transcription_output_file_sh = sharepoint_link + transcription_output_file_sh.replace('.', '')
            os.makedirs(output_relative_path, exist_ok=True)
            with open(transcription_output_file, 'w', encoding='utf-8') as f:
                f.write(transcript)

            # Format the scorecard to the expected output
            formatted_scorecard_df = format_scorecard_to_expected(scores_and_notes_df, file, transcription_output_file_sh, csv_file_name_sh)

            formatted_scorecard_df.columns = ['filename_', 'transcript_location', 'scorefile_location', 'agent_email_id', 'proper_greeting_0_1',
                                              'proper_greeting_notes', 'confirmation_of_contact_and_company_0_2',
                                              'confirmation_of_contact_and_company_notes', 'demonstrated_active_listening_0_5',
                                              'demonstrated_active_listening_notes', 'problem_resolution_0_10',
                                              'problem_resolution_notes', 'remote_support_0_1', 'remote_support_notes',
                                              'professionalism_and_courtesy_0_2', 'professionalism_and_courtesy_notes',
                                              'closing_0_5', 'closing_notes', 'case_number_provision_0_1', 'case_number_provision_notes']
            formatted_scorecard_df['case_number_provision_0_1'].fillna(-1, inplace=True)
            formatted_scorecard_df['case_number_provision_notes'].fillna(' ', inplace=True)
            formatted_scorecard_df['remote_support_0_1'].replace('N/A', -1, inplace=True)
            upload_csv_to_mssql(formatted_scorecard_df, mssql_server, mssql_database, mssql_username, mssql_password, mssql_table)
    
    # Extract the base name from the input zip file (use the first downloaded zip file as an example)
    base_name = os.path.basename(os.path.dirname(os.path.dirname(downloaded_blob_paths[0])))
    # Set the zip file name dynamically based on the base name of the input file
    output_zip_path = os.path.join(output_folder, f"{base_name}_output.zip")

    # Zip the output files
    zip_output_files(output_folder, output_zip_path)

    # Upload the zip file to Azure Blob Storage
    upload_to_azure_blob_storage(azure_blob_connection_string, azure_blob_container_name, output_zip_path, '')

    # Delete processed audio files from Azure Blob Storage
    delete_blob_files(azure_blob_connection_string, azure_blob_container_name, 'input_audio_files')